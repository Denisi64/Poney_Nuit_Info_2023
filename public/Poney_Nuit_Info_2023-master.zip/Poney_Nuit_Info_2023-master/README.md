# Poney_Nuit_Info_2023

## DEFI National - "Changement climatique" :
- Sujet : gaz à effet de serre changement climatique.
 
- Objectif : concevoir un outil ludique et grand public (pédagogique), Démontir les fausses informations , Faire connaître le changement climatique (donner les vraies info par rapports aux idées reçues),Montrer les solutions viables qui existent.

- Contraintes : solutions efficaces sur le long terme et à grande echelle, Soutenues par des mesures politiques, ne pas culpabiliser les utilisateurs, etre juste socialement (voir réduire les inégalités sociales), se référer aux liens données et à des sources fiables, voir le coté économique et aider les plus précaires.

- Link : [site du projet](https://www.nuitdelinfo.com/inscription/defis/174)
- Membres qui participent : [ Tommy / Sylvain ]

---

### Listes 5 défis choisis :
- Défi n°1 : "Où est Charlie ?"
- Défi n°2 : "EasterEgg"
- Défi n°3 : "Tetris 404"
- Défi n°4 : "Movai Code 2023"
- Défi n°5 : "This is better than Hadouken !"

---

## DEFI 1 - "Où est Charlie ?" :
- Link : [site du projet](https://www.nuitdelinfo.com/inscription/defis/393)
- Membres qui participent : [ Neo / Ewen ]

## DEFI 2 - "EasterEgg" :
- Link : [site du projet](https://www.nuitdelinfo.com/inscription/defis/328)
- Membres qui participent : [ Mateo ]

## DEFI 3 - "Tetris 404" :
- Link : [site du projet](https://www.nuitdelinfo.com/inscription/defis/400)
- Membres qui participent : [ Melissa ]

## DEFI 4 - "Movai Code 2023" :
- Link : [site du projet](https://www.nuitdelinfo.com/inscription/defis/410)
- Membres qui participent : [ Simon ]

## DEFI 5 - "This is better than Hadouken !" :
- Link : [site du projet](https://www.nuitdelinfo.com/inscription/defis/332)
- Membres qui participent : [ Achille / Baptiste ]
