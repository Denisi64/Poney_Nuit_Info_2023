const aejfjehjeheojhzeiuehzfhezkjrhezjkhkez = document.createElement('p');
const aejfjehjeheojhroajehfejkqfjehfjezhfkjezhkjzeiuehzfhezkjrhezjkhkez = document.createElement('p');
document.body.appendChild(aejfjehjeheojhzeiuehzfhezkjrhezjkhkez);
document.body.appendChild(aejfjehjeheojhroajehfejkqfjehfjezhfkjezhkjzeiuehzfhezkjrhezjkhkez);

async function afficherLettresAvecChiffrement(chaineD3LaFatigueilest4h, bafbezjkfbejkfbzejkfjkezfjzefhezjfezjkfkj = 0) {
    if (bafbezjkfbejkfbzejkfjkezfjzefhezjfezjkfkj < chaineD3LaFatigueilest4h.length) {
        var Ask1pc3ci3stu3nle11r3d3lAlpraBe1 = chaineD3LaFatigueilest4h[bafbezjkfbejkfbzejkfjkezfjzefhezjfezjkfkj];
        var CET8VariableP3rm3tdeG2R2uneItération = bafbezjkfbejkfbzejkfjkezfjzefhezjfezjkfkj + 1;
        const numberOfIterations = 10000;
        var jeVo0usProm3tsquecemotesttrié = chaineD3LaFatigueilest4h.split('');
        var C3C1IsThPrimerW0urd = chaineD3LaFatigueilest4h.split('').sort().join('');
        while (true) {
            jeVo0usProm3tsquecemotesttrié = jeVo0usProm3tsquecemotesttrié.sort(() => Math.random() - 0.5);
            var C3M0TS0nCourNTcommenRivière = jeVo0usProm3tsquecemotesttrié.join('');
            console.log(`Résultat du tri aléatoire à l'itération ${bafbezjkfbejkfbzejkfjkezfjzefhezjfezjkfkj + 1}: ${C3M0TS0nCourNTcommenRivière}`);

            if (C3M0TS0nCourNTcommenRivière === C3C1IsThPrimerW0urd) {
                break;
            }
        }
        if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'a') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }
            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }

            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'b') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }
            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }
            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'c') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }
            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }
            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'd') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }
            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }
            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'e') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }
            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }
            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'f') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }
            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }
            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'g') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }
            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }
            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'h') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }
            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }
            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'i') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }

            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }
            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'j') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }

            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }

            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'k') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }
            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }

            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'l') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }

            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }
            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'm') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }
            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }
            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'n') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }
            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }
            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'o') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }
            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }

            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'p') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }
            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }
            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'q') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }
            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }
            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'r') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }
            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }
            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 's') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }
            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }

            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 't') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }

            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }

            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'u') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }

            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }

            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'v') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }

            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }

            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'w') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);
            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }
            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }

            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'x') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }

            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }

            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'y') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }

            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }

            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        } else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === 'z') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }

            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }

            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        }
        else if (Ask1pc3ci3stu3nle11r3d3lAlpraBe1 === '-') {
            var J3Su3sUncodemdrIn = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdrIn = (J3Su3sUncodemdrIn * 99999 + 777777) % 1000000007;
            }

            var J3Su3sUncodemdr = Ask1pc3ci3stu3nle11r3d3lAlpraBe1.charCodeAt(0);

            var J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${Ask1pc3ci3stu3nle11r3d3lAlpraBe1}' a été chiffrée en '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}'`);

            for (var grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr = 0; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr < CET8VariableP3rm3tdeG2R2uneItération * 10000; grejgorgjerojrekgjrokhjekljkrlhjlketgjkrejlktjkltjhlrtjhtr++) {
                J3Su3sUncodemdr = (J3Su3sUncodemdr * 123456789 + 987654321) % 1000000007;
            }

            var ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk = String.fromCharCode(J3Su3sUncodemdr);
            console.log(`La lettre '${J3Suis_unchifreemazjfibvjzbvidsjbojzjnkezjvojsdbvezjo}' a été déchiffrée en '${ezjhejldlkvjdkbjekpzjlsklkvlrzkglmsdvmldsjgmrjgk}'`);
        }
        afficherLettresAvecChiffrement(chaineD3LaFatigueilest4h, bafbezjkfbejkfbzejkfjkezfjzefhezjfezjkfkj + 1);
    } else {
        if (bafbezjkfbejkfbzejkfjkezfjzefhezjfezjkfkj < chaineD3LaFatigueilest4h.length) {
            const Ask1pc3ci3stu3nle11r3d3lAlpraBe1 = chaineD3LaFatigueilest4h[bafbezjkfbejkfbzejkfjkezfjzefhezjfezjkfkj].toLowerCase();

            await afficherLettresAvecChiffrement(chaineD3LaFatigueilest4h, bafbezjkfbejkfbzejkfjkezfjzefhezjfezjkfkj + 1);
        } else {
            const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${chaineD3LaFatigueilest4h}`);
            const data = await response.json();

            if (data.length > 0) {
                console.log(`La chaîne '${chaineD3LaFatigueilest4h}' correspond à une ville.`);
                aejfjehjeheojhzeiuehzfhezkjrhezjkhkez.textContent = `La chaîne '${chaineD3LaFatigueilest4h}' correspond à une ville.`;
                const response = await fetch(`https://api.waqi.info/feed/${chaineD3LaFatigueilest4h}/?token=73187c9d408d470b2af1124656c5cb92375cc67b`);
                const data = await response.json();

                if (data.data && data.data.iaqi && data.data.iaqi.co && data.data.iaqi.co.v) {
                    const co2Value = data.data.iaqi.co.v;
                    console.log(`Les émissions de CO2 à ${chaineD3LaFatigueilest4h} sont de ${co2Value} µg/m³`);
                    aejfjehjeheojhroajehfejkqfjehfjezhfkjezhkjzeiuehzfhezkjrhezjkhkez.textContent = `Les émissions de CO2 à ${chaineD3LaFatigueilest4h} sont de ${co2Value} µg/m³`;
                } else {
                    console.log(`Aucune donnée sur les émissions de CO2 n'est disponible pour ${chaineD3LaFatigueilest4h}`);
                    aejfjehjeheojhroajehfejkqfjehfjezhfkjezhkjzeiuehzfhezkjrhezjkhkez.textContent = `Aucune donnée sur les émissions de CO2 n'est disponible pour ${chaineD3LaFatigueilest4h}`;
                }
            } else {
                console.log(`La chaîne '${chaineD3LaFatigueilest4h}' ne correspond pas à une ville connue.`);
                aejfjehjeheojhzeiuehzfhezkjrhezjkhkez.textContent = `La chaîne '${chaineD3LaFatigueilest4h}' ne correspond pas à une ville connue.`;
            }
        }


    }
}